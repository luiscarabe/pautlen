#ifndef SYMBOLS_H
#define SYMBOLS_H

#define OK 0
#define ERR -1



#endif